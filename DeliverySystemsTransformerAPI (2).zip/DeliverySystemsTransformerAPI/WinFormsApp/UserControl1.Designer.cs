﻿
namespace WinFormsApp
{
    partial class UserControl1
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtJson = new TextBox();
            txtXml = new TextBox();
            btnLoadJson = new Button();
            btnLoadXml = new Button();
            dataGridViewMapping = new DataGridView();
            btnGenerateTemplate = new Button();
            txtBoxGenerateLiquid2 = new TextBox();
            btnGenerateLiquid = new Button();
            textBoxXML = new TextBox();
            btnGenerateXML = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridViewMapping).BeginInit();
            SuspendLayout();
            // 
            // txtJson
            // 
            txtJson.Location = new Point(24, 24);
            txtJson.Multiline = true;
            txtJson.Name = "txtJson";
            txtJson.Size = new Size(283, 336);
            txtJson.TabIndex = 0;
            // 
            // txtXml
            // 
            txtXml.Location = new Point(332, 24);
            txtXml.Multiline = true;
            txtXml.Name = "txtXml";
            txtXml.Size = new Size(300, 336);
            txtXml.TabIndex = 1;
            // 
            // btnLoadJson
            // 
            btnLoadJson.Location = new Point(232, 366);
            btnLoadJson.Name = "btnLoadJson";
            btnLoadJson.Size = new Size(75, 23);
            btnLoadJson.TabIndex = 3;
            btnLoadJson.Text = "Load JSON";
            btnLoadJson.UseVisualStyleBackColor = true;
            btnLoadJson.Click += btnLoadJson_Click;
            // 
            // btnLoadXml
            // 
            btnLoadXml.Location = new Point(557, 366);
            btnLoadXml.Name = "btnLoadXml";
            btnLoadXml.Size = new Size(75, 23);
            btnLoadXml.TabIndex = 4;
            btnLoadXml.Text = "Load XML";
            btnLoadXml.UseVisualStyleBackColor = true;
            btnLoadXml.Click += btnLoadXml_Click;
            // 
            // dataGridViewMapping
            // 
            dataGridViewMapping.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewMapping.Location = new Point(24, 421);
            dataGridViewMapping.Name = "dataGridViewMapping";
            dataGridViewMapping.Size = new Size(1243, 336);
            dataGridViewMapping.TabIndex = 5;
            // 
            // btnGenerateTemplate
            // 
            btnGenerateTemplate.Location = new Point(1115, 763);
            btnGenerateTemplate.Name = "btnGenerateTemplate";
            btnGenerateTemplate.Size = new Size(152, 23);
            btnGenerateTemplate.TabIndex = 6;
            btnGenerateTemplate.Text = "Generate Liquid 1";
            btnGenerateTemplate.UseVisualStyleBackColor = true;
            btnGenerateTemplate.Click += btnGenerateTemplate_Click;
            // 
            // txtBoxGenerateLiquid2
            // 
            txtBoxGenerateLiquid2.Location = new Point(656, 24);
            txtBoxGenerateLiquid2.Multiline = true;
            txtBoxGenerateLiquid2.Name = "txtBoxGenerateLiquid2";
            txtBoxGenerateLiquid2.Size = new Size(295, 336);
            txtBoxGenerateLiquid2.TabIndex = 7;
            // 
            // btnGenerateLiquid
            // 
            btnGenerateLiquid.Location = new Point(840, 366);
            btnGenerateLiquid.Name = "btnGenerateLiquid";
            btnGenerateLiquid.Size = new Size(111, 23);
            btnGenerateLiquid.TabIndex = 8;
            btnGenerateLiquid.Text = "Generate Liquid 2";
            btnGenerateLiquid.UseVisualStyleBackColor = true;
            btnGenerateLiquid.Click += btnGenerateLiquid_Click;
            // 
            // textBoxXML
            // 
            textBoxXML.Location = new Point(972, 24);
            textBoxXML.Multiline = true;
            textBoxXML.Name = "textBoxXML";
            textBoxXML.Size = new Size(295, 336);
            textBoxXML.TabIndex = 9;
            // 
            // btnGenerateXML
            // 
            btnGenerateXML.Location = new Point(1156, 366);
            btnGenerateXML.Name = "btnGenerateXML";
            btnGenerateXML.Size = new Size(111, 23);
            btnGenerateXML.TabIndex = 10;
            btnGenerateXML.Text = "Generate XML";
            btnGenerateXML.UseVisualStyleBackColor = true;
            btnGenerateXML.Click += btnGenerateXML_Click;
            // 
            // UserControl1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            Controls.Add(btnGenerateXML);
            Controls.Add(textBoxXML);
            Controls.Add(btnGenerateLiquid);
            Controls.Add(txtBoxGenerateLiquid2);
            Controls.Add(btnGenerateTemplate);
            Controls.Add(dataGridViewMapping);
            Controls.Add(btnLoadXml);
            Controls.Add(btnLoadJson);
            Controls.Add(txtXml);
            Controls.Add(txtJson);
            Location = new Point(100, 100);
            Name = "UserControl1";
            Size = new Size(1416, 877);
            ((System.ComponentModel.ISupportInitialize)dataGridViewMapping).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtJson;
        private TextBox txtXml;
        private Button btnLoadJson;
        private Button btnLoadXml;
        private DataGridView dataGridViewMapping;
        private Button btnGenerateTemplate;
        private TextBox txtBoxGenerateLiquid2;
        private Button btnGenerateLiquid;
        private TextBox textBoxXML;
        private Button btnGenerateXML;
    }
}
