﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using DotLiquid;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;
using Hash = DotLiquid.Hash;
using System.Collections;
using DeliverySystemTransformer_using_liquid_dotliquid;
using DotLiquid.Tags;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Reflection.Metadata;
using Microsoft.VisualBasic.Devices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using ExtensionMethods;

namespace ExtensionMethods
{
    public static class Extensions
    {
        public static string Indent(this string text, int level)
        {
            return "".PadLeft(level*2) + text;
        }
    }
}

namespace WinFormsApp
{
    public partial class UserControl1 : UserControl
    {
        bool isJsonLoaded = false;
        bool isXmlLoaded = false;
        string jsonContent = "";
        string liquidTemplate = "";

        public UserControl1()
        {
            InitializeComponent();
        }

        private void btnLoadJson_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                jsonContent = File.ReadAllText(openFileDialog.FileName);
                string content = JsonConvert.SerializeObject(jsonContent, Formatting.Indented);

                txtJson.Text = IndentWholeTextContent(content.Replace("\\r\\n", System.Environment.NewLine));

                var jsonFields = GetJsonFields(jsonContent);
                if (isXmlLoaded == false)
                {
                    PopulateJSONDataGridView(jsonFields);
                }
                else
                {
                    PopulateDataGridView(jsonFields, GetXmlFields(txtXml.Text));
                }

                isJsonLoaded = true;
            }
        }

        private void btnLoadXml_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*";
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                var content = File.ReadAllText(openFileDialog.FileName);

                txtXml.Text = IndentWholeTextContent(content.Replace("\r\n", System.Environment.NewLine).Replace("\t", ""));

                var xmlFields = GetXmlFields(txtXml.Text);

                if (isJsonLoaded == false)
                {
                    PopulateXMLDataGridView(xmlFields);
                }
                else
                {
                    PopulateDataGridView(GetJsonFields(jsonContent), xmlFields);
                }

                isXmlLoaded = true;
            }
        }

        private void btnGenerateTemplate_Click(object sender, EventArgs e)
        {
            // Generate Liquid template based on the mapping
            liquidTemplate = GenerateLiquidTemplate();

            // Save the Liquid template to a file
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Liquid template files (*.liquid)|*.liquid|All files (*.*)|*.*";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog.FileName, liquidTemplate);
                MessageBox.Show("Liquid template saved successfully.");
            }
        }

        public List<T> Deserialize<T>(string SerializedJSONString)
        {
            var stuff = JsonConvert.DeserializeObject<List<T>>(SerializedJSONString);
            return stuff;
        }

        private string GenerateLiquid2()
        {
            string templateLine = "";
            string template = @"{% for x in replaceThisString -%}" + System.Environment.NewLine;
            template = template.Replace("replaceThisString", FindOriginalParentSection());

            templateLine = "{% for replaceThisString in x.replaceThisString -%}" + System.Environment.NewLine;
            template += templateLine.Indent(1);
            template = template.Replace("replaceThisString", FindOriginalSection());

            templateLine = "<replaceThisString>" + System.Environment.NewLine;
            template += templateLine.Indent(2);
            template = template.Replace("replaceThisString", FindMappedSection());

            templateLine = "<replaceThisString>" + System.Environment.NewLine;
            template += templateLine.Indent(3);
            template = template.Replace("replaceThisString", FindMappedSectionPrefix());
           
            // add identation as well

            foreach (DataGridViewRow row in dataGridViewMapping.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[1].Value != null)
                {
                    var elementOriginalArrays1 = row.Cells[0].Value.ToString().Split('.');
                    var elementMappedArrays2 = row.Cells[1].Value.ToString().Split('.');

                    var lastElement1 = elementOriginalArrays1[elementOriginalArrays1.Length - 1].ToString();
                    var lastElement2 = elementMappedArrays2[elementMappedArrays2.Length - 1].ToString();

                    templateLine = "<" + lastElement2 + ">" + System.Environment.NewLine;
                    template += templateLine.Indent(4);

                    templateLine = "{{ " + FindOriginalSectionPrefix() + "." + lastElement1 + " }}" + System.Environment.NewLine;
                    template += templateLine.Indent(5);

                    templateLine = "</" + lastElement2 + ">" + System.Environment.NewLine;
                    template += templateLine.Indent(4);

                }
            }

            templateLine = "</replaceThisString>" + System.Environment.NewLine;
            template += templateLine.Indent(3);
            template = template.Replace("replaceThisString", FindMappedSectionPrefix());

            templateLine = "</replaceThisString>" + System.Environment.NewLine;
            template += templateLine.Indent(2);
            template = template.Replace("replaceThisString", FindMappedSection());

            templateLine = "{% endfor -%}" + System.Environment.NewLine;
            template += templateLine.Indent(1);

            template += "{% endfor -%}" + System.Environment.NewLine;

            return template;
        }

        private string GenerateXMLBasedOnLiquidTemplate()
        {
            var inputString1 = @"{
              ""loanApplication"": {
                ""deal"": {
                  ""applicantGroup"": [
                    {
                      ""applicantGroupTypeDd"": 0,
                      ""applicant"": [
                        {
                          ""birthDate"": ""1985-04-29"",
                          ""emailAddress"": ""Neha.Nagda@firstnational.ca"",
                          ""name"": {
                            ""firstName"": ""Allocation"",
                            ""lastName"": ""Insurer""
                          },
                          ""phone"": [
                            {
                              ""phoneTypeDd"": 2,
                              ""phoneNumber"": ""6471234560""
                            },
				            {
                              ""phoneTypeDd"": 4,
                              ""phoneNumber"": ""4162014444""
                            }
                          ],
                          ""preferredContactMethodDd"": 1
                        }
                      ]
                    }
                  ]
                }
              }
            }";

            var inputString2 = @"
                {
                    'content': {
                        'firstName': 'John',
                        'lastName': 'Doe',
                        'phone': '+1234567890',
                        'devices': 'Laptop, Smartphone, Tablet'
                    }
                }"
            ;

            var mappedTemplate = @"{% for group in loanApplication %}
            {{ group.deal.applicantGroup.applicant.name.firstName }} -> {{ group.Applicant1.Name1.FirstName1 }}
            {{ group.deal.applicantGroup.applicant.name.lastName }} -> {{ group.Applicant1.Name1.LastName1 }}
            {% endfor %}";

            // Build the generated template based on the mapping fom above

            var generatedTemplate = @"{% for group in loanApplication.deal.applicantGroup -%}
                {% for applicant in group.applicant -%}
                  <Applicant1>
                    <Name1>
                      <FirstName1>{{ applicant.name.firstName }}</FirstName1>
                      <LastName1>{{ applicant.name.lastName }}</LastName1>
                    </Name1>
                   </Applicant1>
                {% endfor -%}
              {% endfor -%}";
            ;

            var templateString1 = @" < Deal>
              {% for group in loanApplication.deal.applicantGroup -%}
                {% for applicant in group.applicant -%}
                  <Applicant>
                    <Name>
                      <FirstName>{{ applicant.name.firstName }}</FirstName>
                      <LastName>{{ applicant.name.lastName }}</LastName>
                    </Name>
                    <PreferredContactMethod>{{ applicant.preferredContactMethodDd }}</PreferredContactMethod>
                    <ContactMethods>
                      {% for phone in applicant.phone -%}
                        <Telephone>
                          <TelType>{% case phone.phoneTypeDd -%}{% when 1 -%}0{% when 2 -%}1{% when 3 -%}4{% when 4 -%}2{% else -%}{{ phone.phoneTypeDd }}{% endcase -%}</TelType>
                          <TelNumber>{{ phone.phoneNumber }}</TelNumber>
                        </Telephone>
                      {% endfor -%}
                      <Email>
                        <EmailAddress>{{ applicant.emailAddress }}</EmailAddress>
                      </Email>
                    </ContactMethods>
                  </Applicant>
                {% endfor -%}
              {% endfor -%}
            </Deal>";

            var templateString2 = @"{% -assign deviceList = content.devices | Split: ', ' -%}
            {
                fullName: { { content.firstName | Append: ' ' | Append: content.lastName} }
                firstNameUpperCase: { { content.firstName | Upcase} }
                phoneAreaCode: { { content.phone | Slice: 1, 3} }
                devices : [
                {% - for device in deviceList -%}
                    {% - if forloop.Last == true -%}
                        { { device} }                                
                    {% - else -%}
                    { { device} }
                    {% -endif -%}
                {% -endfor -%}
                ]
            }";

            var templateString3 = @"Name: { { content.firstName } }
            { { content.lastName } }
                Phone: { { content.phone } }
                Devices: { { content.devices } }";

            ILiquidTransform transform = new JsonLiquidTransform();
            //var result = transform.ExecuteLiquidTransform(templateString1, inputString1);
            var result = transform.ExecuteLiquidTransform(generatedTemplate, inputString1);

            return result;
        }

        private string GenerateXMLBasedOnLiquidTemplate2()
        {
            var inputString1 = @"{
              ""loanApplication"": {
                ""deal"": {
                  ""applicantGroup"": [
                    {
                      ""applicantGroupTypeDd"": 0,
                      ""applicant"": [
                        {
                          ""birthDate"": ""1985-04-29"",
                          ""emailAddress"": ""Neha.Nagda@firstnational.ca"",
                          ""name"": {
                            ""firstName"": ""Allocation"",
                            ""lastName"": ""Insurer""
                          },
                          ""phone"": [
                            {
                              ""phoneTypeDd"": 2,
                              ""phoneNumber"": ""6471234560""
                            },
				            {
                              ""phoneTypeDd"": 4,
                              ""phoneNumber"": ""4162014444""
                            }
                          ],
                          ""preferredContactMethodDd"": 1
                        }
                      ]
                    }
                  ]
                }
              }
            }";


            ILiquidTransform transform = new JsonLiquidTransform();

            var result = transform.ExecuteLiquidTransform(txtBoxGenerateLiquid2.Text, inputString1);

            var indentedResult = IndentWholeTextContent(result);

            return indentedResult;
        }

        private string IndentWholeTextContent(string content)
        {
            // will need to transform this to indent
            var lines = content.Split(new string[] { Environment.NewLine }, StringSplitOptions.None).ToList();

            string indentedResult = "";
            int i = 0;
            int firstEndTagCount = 0;
            foreach (string line in lines)
            {
                if (i > 0)
                {
                    indentedResult += line.Indent(i) + System.Environment.NewLine;
                }
                else
                {
                    indentedResult += line + System.Environment.NewLine;
                }

                if (!line.Contains("</") || firstEndTagCount == 0)
                {
                    i++;

                    firstEndTagCount++;
                }

                if (firstEndTagCount > 1)
                {
                    i--;
                }

            }

            return indentedResult;
        }

        private void btnGenerateLiquid_Click(object sender, EventArgs e)
        {
            txtBoxGenerateLiquid2.Text = GenerateLiquid2();
        }

        private void btnGenerateXML_Click(object sender, EventArgs e)
        {
            textBoxXML.Text = GenerateXMLBasedOnLiquidTemplate2();
        }       

        private string FindOriginalSectionPrefix()
        {
            // find the common keyword moving backwards = name and its parent = applicant

            return "applicant.name";
        }

        private string FindOriginalSection()
        {
            // find the common keyword moving backwards = name and its parent = applicant
            return "applicant";
        }

        private string FindOriginalParentSection()
        {
            // everything else before SectionPrefix
            return "loanApplication.deal.applicantGroup";
        }

        private string FindMappedSectionPrefix()
        {
            // find the common keyword moving backwards = name and its parent = applicant

            return "Name1";
        }

        private string FindMappedSection()
        {
            // find the common keyword moving backwards = name and its parent = applicant
            return "Applicant1";
        }

        private string GenerateLiquidTemplate()
        {
            // Generate Liquid template based on the mapping

            string template = "";
            foreach (DataGridViewRow row in dataGridViewMapping.Rows)
            {
                if (row.Cells[0].Value != null && row.Cells[1].Value != null)
                {
                    template += $"{{{{ group.{row.Cells[0].Value} }}}} -> {{{{ group.{row.Cells[1].Value} }}}}\n";
                }
            }

            return template;           
        }

        private List<string> GetJsonFields(string json)
        {
            var fields = new List<string>();

            //JArray jsonArray = JArray.Parse(json);
            //var jObject = JObject.Parse(jsonArray[0].ToString());

            var jObject = JObject.Parse(json);

            ExtractJsonFields(jObject, fields, "");
            return fields;
        }

        private void ExtractJsonFields(JToken token, List<string> fields, string prefix)
        {
            if (token is JObject)
            {
                foreach (var property in token.Children<JProperty>())
                {
                    ExtractJsonFields(property.Value, fields, $"{prefix}{property.Name}.");
                }
            }
            else if (token is JArray)
            {
                ExtractJsonFields(token.First, fields, prefix);
            }
            else
            {
                fields.Add(prefix.TrimEnd('.'));
            }
        }

        private List<string> GetXmlFields(string xml)
        {
            var fields = new List<string>();
            var xDocument = XDocument.Parse(xml);
            ExtractXmlFields(xDocument.Root, fields, "");
            return fields;
        }

        private void ExtractXmlFields(XElement element, List<string> fields, string prefix)
        {
            foreach (var child in element.Elements())
            {
                ExtractXmlFields(child, fields, $"{prefix}{child.Name.LocalName}.");
            }
            fields.Add(prefix.TrimEnd('.'));
        }

        private void PopulateJSONDataGridView(List<string> jsonFields)
        {
            var jsonColumn = new DataGridViewComboBoxColumn
            {
                HeaderText = "JSON Field",
                DataSource = jsonFields
            };

            dataGridViewMapping.Columns.Clear();
            dataGridViewMapping.Columns.Add(jsonColumn);
        }

        private void PopulateXMLDataGridView(List<string> xmlFields)
        {
            var xmlColumn = new DataGridViewComboBoxColumn
            {
                HeaderText = "XML Field",
                DataSource = xmlFields
            };

            dataGridViewMapping.Columns.Clear();
            dataGridViewMapping.Columns.Add(xmlColumn);
        }

        private void PopulateDataGridView(List<string> jsonFields, List<string> xmlFields)
        {
            var jsonColumn = new DataGridViewComboBoxColumn
            {
                HeaderText = "JSON Field",
                DataSource = jsonFields
            };

            var xmlColumn = new DataGridViewComboBoxColumn
            {
                HeaderText = "XML Field",
                DataSource = xmlFields
            };

            dataGridViewMapping.Columns.Clear();
            dataGridViewMapping.Columns.Add(jsonColumn);
            dataGridViewMapping.Columns.Add(xmlColumn);
        }       

    }
}