﻿namespace DeliverySystemTransformer_using_liquid_dotliquid
{
    public interface ILiquidTransform
    {
        public string ExecuteLiquidTransform(string templateString, string dataString);
    }
}
