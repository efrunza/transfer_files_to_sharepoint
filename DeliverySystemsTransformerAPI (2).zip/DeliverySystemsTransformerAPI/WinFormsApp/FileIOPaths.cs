﻿namespace DeliverySystemTransformer_using_liquid_dotliquid
{
    public class FileIOPaths
    {
        public string TemplateFilePath { get; set; } = String.Empty;
    }
}
