﻿using System.Xml;

namespace DeliverySystemTransformer_using_liquid_dotliquid
{
    public class XmlDictionaryConverter
    {
        public Dictionary<string, object> ConvertXmlToDictionary(string xml)
        {
            var xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xml);
            return ConvertXmlNodeToDictionary(xmlDoc.DocumentElement);
        }

        private Dictionary<string, object> ConvertXmlNodeToDictionary(XmlNode node)
        {
            var dict = new Dictionary<string, object>();

            foreach (XmlNode childNode in node.ChildNodes)
            {
                if (childNode.HasChildNodes && childNode.FirstChild.NodeType == XmlNodeType.Element)
                {
                    dict[childNode.Name] = ConvertXmlNodeToDictionary(childNode);
                }
                else
                {
                    dict[childNode.Name] = childNode.InnerText;
                }
            }

            return dict;
        }
    }
}
