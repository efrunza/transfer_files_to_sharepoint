﻿using DotLiquid;
using Newtonsoft.Json;

namespace DeliverySystemTransformer_using_liquid_dotliquid
{
    public class JsonLiquidTransform : ILiquidTransform
    {

        public string ExecuteLiquidTransform(string templateString, string jsonString)
        {
            string returnValue = "";

            // Step 1: Define the template string

            
            try
            {
                // Step 2: Parse the template
                Template template = Template.Parse(templateString);

                // Step 3: Deserialize the JSON string into a .NET object

                var jsonObject = JsonConvert.DeserializeObject<Dictionary<string, object>>(jsonString, new DictionaryConverter());
                var jsonHash = Hash.FromDictionary(jsonObject);

                // Step 4: Render the template with the JSON object
                string result = template.Render(Hash.FromDictionary(jsonObject));

                returnValue = result.ToString();
            }
            catch (Exception ex)
            {
                returnValue = ex.Message;
            }

            return returnValue;
        }
    }
}
