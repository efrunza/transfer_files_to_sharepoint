﻿using DotLiquid;
using System.Xml;

namespace DeliverySystemTransformer_using_liquid_dotliquid
{
    public class XmlLiquidTransform : ILiquidTransform
    {
        public string ExecuteLiquidTransform(string templateString, string xmlString)
        {
            string returnValue = "";

            // Step 1: Define the template string


            try
            {
                // Step 2: Parse the template
                Template template = Template.Parse(templateString);

                // Step 3: Deserialize the JSON string into a .NET object
                XmlDictionaryConverter converter = new XmlDictionaryConverter();
                var jsonObject = converter.ConvertXmlToDictionary(xmlString);
                var jsonHash = Hash.FromDictionary(jsonObject);

                // Step 4: Render the template with the JSON object
                string result = template.Render(Hash.FromDictionary(jsonObject));

                returnValue = result.ToString();
            }
            catch (Exception ex)
            {
                returnValue = ex.Message;
            }

            return returnValue;
        }

        
    }
}
